﻿Imports Microsoft.VisualBasic

Public Class globals
    Public Shared ReadOnly Property AzureConnection() As String
        Get
            Return "Server=tcp:is9ofoay2e.database.windows.net,1433;Database=bookCollection;User ID=deletemedbadmin@is9ofoay2e;Password=P@ssw0rd;Trusted_Connection=False;Encrypt=True;Connection Timeout=30;"
        End Get
    End Property
End Class
